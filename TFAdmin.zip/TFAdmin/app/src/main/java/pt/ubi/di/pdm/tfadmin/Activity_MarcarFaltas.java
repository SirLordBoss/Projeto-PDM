package pt.ubi.di.pdm.tfadmin;

import android.app.Activity;

public class Activity_MarcarFaltas extends Activity {
}
